package Bader;




public class constants {
	public static final int MAX_PRICE = 30000;/**Konstanterna �ndras inte*/
	public static final int  MIN_PRICE = 0;
	public static final int MAX_SIZE = 28;
	public static final int MIN_SIZE = 8;
	
	public static final String [] COLORS = {"blue","red", "yellow", "black", "orange", "grey"};
	
		
		
	}
	
	

	
	

	
