import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import se.mah.k3lara.skaneAPI.control.Constants;
import se.mah.k3lara.skaneAPI.model.Journey;
import se.mah.k3lara.skaneAPI.model.Journeys;
import se.mah.k3lara.skaneAPI.model.Station;
import se.mah.k3lara.skaneAPI.xmlparser.Parser;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Calendar;
import java.awt.event.ActionEvent;

public class trafikGUI extends JFrame {

	private JPanel contentPane;
	private JTextField fr�nField;
	private JTextField tillField;
	private JTextField stationField;
	private JTextArea stationArea;
	private JTextArea tripArea;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					trafikGUI frame = new trafikGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public trafikGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 707, 531);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 55, 43);
		contentPane.add(panel);

		fr�nField = new JTextField();
		fr�nField.setBounds(97, 123, 116, 22);
		contentPane.add(fr�nField);
		fr�nField.setColumns(10);

		tillField = new JTextField();
		tillField.setColumns(10);
		tillField.setBounds(97, 186, 116, 22);
		contentPane.add(tillField);

		JLabel lblVljHllplats = new JLabel("V\u00E4lj H\u00E5llplats");
		lblVljHllplats.setBounds(10, 56, 156, 42);
		contentPane.add(lblVljHllplats);

		JLabel lblFrn = new JLabel("FR\u00C5N");
		lblFrn.setBounds(12, 126, 56, 16);
		contentPane.add(lblFrn);

		JLabel lblTill = new JLabel("Till");
		lblTill.setBounds(10, 192, 75, 16);
		contentPane.add(lblTill);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(415, 30, 221, 195);
		contentPane.add(scrollPane);

		tripArea = new JTextArea();
		scrollPane.setViewportView(tripArea);
		tripArea.setRows(20);
		tripArea.setColumns(10);

		JButton s�kButton = new JButton("S\u00F6k");
		s�kButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				tripArea.setText("Hittar dina resor...");
				new TripTr�d().start();

			}

		});
		s�kButton.setFont(new Font("Calibri", Font.BOLD | Font.ITALIC, 19));
		s�kButton.setBounds(97, 237, 116, 33);
		contentPane.add(s�kButton);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(419, 241, 221, 195);
		contentPane.add(scrollPane_1);

		stationArea = new JTextArea();
		scrollPane_1.setViewportView(stationArea);
		stationArea.setRows(20);
		stationArea.setColumns(10);

		stationField = new JTextField();
		stationField.setColumns(10);
		stationField.setBounds(97, 305, 116, 22);
		contentPane.add(stationField);

		JLabel lblTgresaSkanetrafiken = new JLabel("T\u00C5GRESA SKANETRAFIKEN");
		lblTgresaSkanetrafiken.setFont(new Font("Calibri", Font.BOLD, 19));
		lblTgresaSkanetrafiken.setBounds(136, 13, 239, 36);
		contentPane.add(lblTgresaSkanetrafiken);

		JButton stationButton = new JButton("S\u00F6k");
		stationButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stationArea.setText("S�ker...");
				new StationTr�d().start();

			}
		});
		stationButton.setFont(new Font("Calibri", Font.BOLD | Font.ITALIC, 19));
		stationButton.setBounds(97, 363, 116, 33);
		contentPane.add(stationButton);
	}

	private class StationTr�d extends Thread {
		@Override
		public void run() {
			String hittaStation = stationField.getText();// tar str�ngen fr�n
															// stationfield
			System.out.println("// Stations when searching for stations containing \"Malm\"");
			ArrayList<Station> searchStations = new ArrayList<Station>(); // S�tter
																			// i
																			// g�ng
																			// arraylistan
																			// och
																			// s�ker
			searchStations.addAll(Parser.getStationsFromURL(hittaStation));
			stationArea.setText("");// Clearar s�krutan innan den b�rjar visa
									// s�kningen
			for (Station s : searchStations) {// s�tter ig�ng
				stationArea.append(s.getStationName() + " number:" + s.getStationNbr() + "\n");
			}

		}
	}

	private class TripTr�d extends Thread {
		@Override
		public void run() {

			String fr�n = fr�nField.getText();
			String till = tillField.getText();
			String searchURL = Constants.getURL(fr�n, till, 5);
			Journeys journeys = Parser.getJourneys(searchURL);
			tripArea.setText("");
			for (Journey journey : journeys.getJourneys()) {
				System.out.print(journey.getStartStation() + " - ");
				System.out.print(journey.getEndStation());
				String time = journey.getDepDateTime().get(Calendar.HOUR_OF_DAY) + ":"
						+ journey.getDepDateTime().get(Calendar.MINUTE);
				tripArea.append(" Departs " + time + " that is in " + journey.getTimeToDeparture()
						+ " minutes. And it is " + journey.getDepTimeDeviation() + " min late" + "\n");

			}
		}
	}

}
